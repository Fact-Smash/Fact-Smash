package edu.ncsu.csc.itrust2.unit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.ncsu.csc.itrust2.forms.admin.PharmacyForm;
import edu.ncsu.csc.itrust2.models.enums.State;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;

/**
 * Tests the constructors and methods of PharmacyForm.
 *
 * @author twzheng
 *
 */
public class PharmacyFormTest {

    /**
     * Test the PharmacyForm class.
     */
    @Test
    public void testPharmacyForm () {
        final Pharmacy pharmacy = new Pharmacy();
        pharmacy.setAddress( "123 abc road" );
        pharmacy.setName( "some pharmacy" );
        pharmacy.setState( State.NC );
        pharmacy.setZip( "27040" );
        final PharmacyForm form = new PharmacyForm( pharmacy );
        assertEquals( pharmacy.getAddress(), form.getAddress() );
        assertEquals( pharmacy.getAddress2(), form.getAddress2() );
        assertEquals( pharmacy.getName(), form.getName() );
        assertEquals( pharmacy.getState().getName(), form.getState() );
        assertEquals( pharmacy.getZip(), form.getZip() );

        // Test with optional address 2 field
        final Pharmacy pharmacy2 = new Pharmacy();
        pharmacy2.setAddress( "123 xyz road" );
        pharmacy2.setAddress2( "building 2" );
        pharmacy2.setName( "some other pharmacy" );
        pharmacy2.setState( State.NC );
        pharmacy2.setZip( "27040" );
        final PharmacyForm form2 = new PharmacyForm( pharmacy2 );
        assertEquals( pharmacy2.getAddress(), form2.getAddress() );
        assertEquals( pharmacy2.getName(), form2.getName() );
        assertEquals( pharmacy2.getState().getName(), form2.getState() );
        assertEquals( pharmacy2.getZip(), form2.getZip() );
    }
}
