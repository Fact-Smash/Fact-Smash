package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.paulhammant.ngwebdriver.NgWebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.persistent.Drug;
import edu.ncsu.csc.itrust2.models.persistent.Personnel;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.Prescription;
import edu.ncsu.csc.itrust2.models.persistent.User;

public class FillPrescriptionStepDefs extends CucumberTest {

    private final String baseUrl = "http://localhost:8080/iTrust2/";
    private Personnel    pharmacist;
    private Pharmacy     pharmacy;

    @Given ( "a pharmacist (.+) is assigned to a pharmacy (.+)" )
    public void confirmPharmacistAssigned ( final String name, final String place ) {

        generatePrescriptions();
        pharmacist = Personnel.getByName( name );
        if ( pharmacist == null ) {
            final User user = new User( name, "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                    Role.ROLE_PHARMACIST, 1 );
            user.save();
            pharmacist = new Personnel();
            pharmacist.setSelf( user );
            pharmacist.save();
        }
        pharmacy = Pharmacy.getByName( place );
        if ( pharmacy == null ) {
            pharmacy = new Pharmacy( place, "Address", "", "11111", "Alabama" );
            pharmacy.save();
        }
        if ( !pharmacist.getHospitalId().equals( pharmacy.getName() ) ) {
            pharmacist.setHospitalId( pharmacy.getName() );
        }
    }

    @Given ( "I have logged in as pharmacist (.+)" )
    public void pharmacistLogin ( final String name ) throws ParseException {
        attemptLogout();

        driver.get( baseUrl );
        waitForAngular();
        final WebElement username = driver.findElement( By.name( "username" ) );
        username.clear();
        username.sendKeys( name );
        final WebElement password = driver.findElement( By.name( "password" ) );
        password.clear();
        password.sendKeys( "123456" );
        final WebElement submit = driver.findElement( By.className( "btn" ) );
        submit.click();
        waitForAngular();
    }

    @When ( "^I go to the Fill Prescriptions tab$" )
    public void viewFillPrescriptions () {
        driver.get( baseUrl + "pharmacist/fillPrescriptions" );
    }

    @Override
    protected void waitForAngular () {
        new NgWebDriver( CucumberTest.driver ).waitForAngularRequestsToFinish();
    }

    @When ( "^I look at patient (.+)\'s prescription and I select to fill it with (.+) and submit$" )
    public void selectPrescription ( final String patient, final String selection ) {
        waitForAngular();
        int tableIndex = -1;
        final List<Prescription> prescriptions = Prescription.getForPharmacy( pharmacy.getName() );
        for ( int i = 1; i < prescriptions.size() + 1; i++ ) {
            try {
                final String xpathstring = "/html/body/div/div[1]/div[1]/div/div[1]/div/div/div/div[2]/table/tbody/tr["
                        + i + "]/td[1]";
                waitForAngular();
                if ( driver.findElement( By.xpath( xpathstring ) ).getText().equals( patient ) ) {
                    tableIndex = i - 1;
                }
            }
            catch ( final NoSuchElementException e ) {

            }
        }
        waitForAngular();
        driver.findElement( By.name( "fillWith" + tableIndex ) ).sendKeys( selection );
        waitForAngular();
        driver.findElement( By.cssSelector( "input[type=button][name=fillPrescription" + tableIndex + "]" ) ).click();
        try {
            Thread.sleep( 200 );
            driver.switchTo().alert().accept();
        }
        catch ( final Exception e ) {

        }
        try {
            Thread.sleep( 200 );
            driver.switchTo().alert().accept();
        }
        catch ( final Exception e ) {

        }
        try {
            Thread.sleep( 200 );
            driver.switchTo().alert().accept();
        }
        catch ( final Exception e ) {

        }
    }

    @Then ( "^(.+)'s prescription is responded to.$" )
    public void confirmPrescriptionFilled ( final String name ) {
        waitForAngular();
        final List<Prescription> prescriptions = Prescription.getForPharmacy( pharmacy.getName() );
        Prescription toCheck = null;
        for ( final Prescription prescription : prescriptions ) {
            if ( prescription.getPatient().getUsername().equals( name ) ) {
                toCheck = prescription;
            }
        }
        waitForAngular();
        assertTrue( toCheck.getResponded() );
    }

    public static void generatePrescriptions () {
        final User user = User.getByName( "pharmacist" );
        final Personnel pharmacist = new Personnel();
        pharmacist.setSelf( user );
        pharmacist.save();
        final Drug drug = new Drug();
        drug.setCode( "1000-0001-11" );
        drug.setName( "Ibuprofen" );
        drug.setDescription( "pain and stuff" );
        drug.save();
        final User patient = new User( "AndrewF", "123456", Role.ROLE_PATIENT, 1 );
        patient.save();
        final Pharmacy pharmacy = Pharmacy.getByName( "pharmacy" );
        pharmacist.setHospitalId( pharmacy.getName() );
        pharmacist.save();
        final Prescription prescription = new Prescription();
        prescription.setDrug( drug );
        prescription.setDosage( 500 );
        prescription.setStartDate( LocalDate.of( 2020, 01, 01 ) );
        prescription.setEndDate( LocalDate.of( 2021, 01, 01 ) );
        prescription.setRenewals( 1 );
        prescription.setPatient( patient );
        prescription.setLocation( pharmacy );
        prescription.setWantsGeneric( true );
        prescription.setFilled( false );
        prescription.setIsGeneric( false );
        prescription.setResponded( false );
        prescription.save();

        final User user1 = new User( "PharmaBro", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                Role.ROLE_PHARMACIST, 1 );
        user1.save();
        final User patient1 = new User( "Gary", "123456", Role.ROLE_PATIENT, 1 );
        patient1.save();
        final Pharmacy pharmacy1 = new Pharmacy( "AnimalPharm", "Somewhere", "", "12345", "New York" );
        pharmacy1.save();
        final Personnel pharmacist1 = new Personnel();
        pharmacist1.setSelf( user1 );
        pharmacist1.setHospitalId( pharmacy1.getName() );
        pharmacist1.save();
        final Drug drug1 = new Drug();
        drug1.setCode( "1000-0010-00" );
        drug1.setName( "Percocet" );
        drug1.setDescription( "More pain and stuff" );
        drug1.save();
        final Prescription prescription1 = new Prescription();
        prescription1.setDrug( drug1 );
        prescription1.setDosage( 500 );
        prescription1.setStartDate( LocalDate.of( 2020, 01, 01 ) );
        prescription1.setEndDate( LocalDate.of( 2021, 01, 01 ) );
        prescription1.setRenewals( 1 );
        prescription1.setPatient( patient1 );
        prescription1.setLocation( pharmacy1 );
        prescription1.setWantsGeneric( false );
        prescription1.setFilled( false );
        prescription1.setIsGeneric( false );
        prescription1.setResponded( false );
        prescription1.save();

        final User patient2 = new User( "Cynthia", "123456", Role.ROLE_PATIENT, 1 );
        patient2.save();
        final Prescription prescription2 = new Prescription();
        prescription2.setDrug( drug1 );
        prescription2.setDosage( 500 );
        prescription2.setStartDate( LocalDate.of( 2020, 01, 01 ) );
        prescription2.setEndDate( LocalDate.of( 2021, 01, 01 ) );
        prescription2.setRenewals( 1 );
        prescription2.setPatient( patient2 );
        prescription2.setLocation( pharmacy );
        prescription2.setWantsGeneric( false );
        prescription2.setFilled( false );
        prescription2.setIsGeneric( false );
        prescription2.setResponded( false );
        prescription2.save();

        final User patient3 = new User( "Marcus", "123456", Role.ROLE_PATIENT, 1 );
        patient3.save();
        final Prescription prescription3 = new Prescription();
        prescription3.setDrug( drug );
        prescription3.setDosage( 500 );
        prescription3.setStartDate( LocalDate.of( 2020, 01, 01 ) );
        prescription3.setEndDate( LocalDate.of( 2021, 01, 01 ) );
        prescription3.setRenewals( 1 );
        prescription3.setPatient( patient3 );
        prescription3.setLocation( pharmacy );
        prescription3.setWantsGeneric( true );
        prescription3.setFilled( false );
        prescription3.setIsGeneric( false );
        prescription3.setResponded( false );
        prescription3.save();
    }

}
