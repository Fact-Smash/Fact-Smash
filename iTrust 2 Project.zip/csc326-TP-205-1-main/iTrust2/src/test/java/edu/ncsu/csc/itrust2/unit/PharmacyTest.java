package edu.ncsu.csc.itrust2.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import edu.ncsu.csc.itrust2.forms.admin.PharmacyForm;
import edu.ncsu.csc.itrust2.models.enums.State;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;

/**
 * Tests the constructors and methods of Pharmacy.
 *
 * @author twzheng
 *
 */
public class PharmacyTest {

    /**
     * Test the Pharmacy class.
     */
    @Test
    public void testPharmacy () {
        // Testing normal constructor
        final Pharmacy pharmacy = new Pharmacy( "abc pharmacy", "123 road", "", "11111", "North Carolina" );
        assertEquals( pharmacy.getName(), "abc pharmacy" );
        assertEquals( pharmacy.getAddress(), "123 road" );
        assertEquals( pharmacy.getAddress2(), "" );
        assertEquals( pharmacy.getZip(), "11111" );
        assertEquals( pharmacy.getState().getName(), "North Carolina" );

        // Testing constructing via PharmacyForm
        final PharmacyForm pf = new PharmacyForm();
        pf.setName( "some place" );
        pf.setAddress( "somewhere" );
        pf.setAddress2( "" );
        pf.setZip( "22222" );
        pf.setState( "North Carolina" );
        final Pharmacy pharmacy2 = new Pharmacy( pf );
        assertEquals( pharmacy2.getName(), pf.getName() );
        assertEquals( pharmacy2.getAddress(), pf.getAddress() );
        assertEquals( pharmacy2.getAddress2(), pf.getAddress2() );
        assertEquals( pharmacy2.getZip(), pf.getZip() );
        assertEquals( pharmacy2.getState().getName(), pf.getState() );

        // Testing constructing via empty constructor and setters
        final Pharmacy pharmacy3 = new Pharmacy();
        pharmacy3.setName( "xyz mart" );
        pharmacy3.setAddress( "wasd street" );
        pharmacy3.setAddress2( "Building 123" );
        pharmacy3.setZip( "33333" );
        pharmacy3.setState( State.NC );
        assertEquals( pharmacy3.getName(), "xyz mart" );
        assertEquals( pharmacy3.getAddress(), "wasd street" );
        assertEquals( pharmacy3.getAddress2(), "Building 123" );
        assertEquals( pharmacy3.getZip(), "33333" );
        assertEquals( pharmacy3.getState().getName(), "North Carolina" );
    }

    /**
     * Tests the Pharmacy object in database
     */
    @Test
    public void testPharmacyDB () {
        // Delete existing testing pharmacies
        Pharmacy pharmacy = Pharmacy.getByName( "_testing_pharmacy_1" );
        Pharmacy pharmacy2 = Pharmacy.getByName( "_testing_pharmacy_2" );
        Pharmacy pharmacy3 = Pharmacy.getByName( "_testing_pharmacy_3" );
        if ( pharmacy != null ) {
            pharmacy.delete();
        }
        if ( pharmacy2 != null ) {
            pharmacy2.delete();
        }
        if ( pharmacy3 != null ) {
            pharmacy3.delete();
        }

        // Track the original size of the pharmacy
        final int initialCount = Pharmacy.getPharmacies().size();

        // Construct a few pharmacies
        pharmacy = new Pharmacy( "_testing_pharmacy_1", "_test_road_1", "", "11111", "North Carolina" );
        pharmacy2 = new Pharmacy( "_testing_pharmacy_2", "_test_road_2", "_test_building_1", "11111",
                "North Carolina" );
        pharmacy3 = new Pharmacy( "_testing_pharmacy_3", "_test_road_2", "_test_building_2", "11111",
                "North Carolina" );

        // Save them to the database, one by one
        pharmacy.save();
        Pharmacy pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_1" );
        assertEquals( pharmacyDb.getName(), "_testing_pharmacy_1" );
        assertEquals( pharmacyDb.getAddress(), "_test_road_1" );
        assertEquals( pharmacyDb.getAddress2(), "" );
        assertEquals( pharmacyDb.getZip(), "11111" );
        assertEquals( pharmacyDb.getState().getName(), "North Carolina" );
        assertEquals( 1, Pharmacy.getPharmacies().size() - initialCount );

        pharmacy2.save();
        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_2" );
        assertEquals( pharmacyDb.getName(), "_testing_pharmacy_2" );
        assertEquals( pharmacyDb.getAddress(), "_test_road_2" );
        assertEquals( pharmacyDb.getAddress2(), "_test_building_1" );
        assertEquals( pharmacyDb.getZip(), "11111" );
        assertEquals( pharmacyDb.getState().getName(), "North Carolina" );
        assertEquals( 2, Pharmacy.getPharmacies().size() - initialCount );

        pharmacy3.save();
        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_3" );
        assertEquals( pharmacyDb.getName(), "_testing_pharmacy_3" );
        assertEquals( pharmacyDb.getAddress(), "_test_road_2" );
        assertEquals( pharmacyDb.getAddress2(), "_test_building_2" );
        assertEquals( pharmacyDb.getZip(), "11111" );
        assertEquals( pharmacyDb.getState().getName(), "North Carolina" );
        assertEquals( 3, Pharmacy.getPharmacies().size() - initialCount );

        // Edit the first pharmacy
        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_1" );
        pharmacyDb.setAddress( "_somewhere_else" );
        pharmacyDb.setZip( "22222" );
        pharmacyDb.setState( State.NY );
        pharmacyDb.save();
        assertEquals( pharmacyDb.getName(), "_testing_pharmacy_1" );
        assertEquals( pharmacyDb.getAddress(), "_somewhere_else" );
        assertEquals( pharmacyDb.getAddress2(), "" );
        assertEquals( pharmacyDb.getZip(), "22222" );
        assertEquals( pharmacyDb.getState().getName(), "New York" );
        assertEquals( 3, Pharmacy.getPharmacies().size() - initialCount );

        // Delete them from the database, one by one
        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_1" );
        pharmacyDb.delete();
        assertNull( Pharmacy.getByName( "_testing_pharmacy_1" ) );
        assertEquals( 2, Pharmacy.getPharmacies().size() - initialCount );

        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_2" );
        pharmacyDb.delete();
        assertNull( Pharmacy.getByName( "_testing_pharmacy_2" ) );
        assertEquals( 1, Pharmacy.getPharmacies().size() - initialCount );

        pharmacyDb = Pharmacy.getByName( "_testing_pharmacy_3" );
        pharmacyDb.delete();
        assertNull( Pharmacy.getByName( "_testing_pharmacy_3" ) );
        assertEquals( 0, Pharmacy.getPharmacies().size() - initialCount );
    }

}
