package edu.ncsu.csc.itrust2.apitest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.itrust2.config.RootConfiguration;
import edu.ncsu.csc.itrust2.forms.admin.PharmacyForm;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.mvc.config.WebMvcConfiguration;

/**
 * Test for API functionality for interacting with Pharmacies
 *
 * @author twzheng
 *
 */
@RunWith ( SpringJUnit4ClassRunner.class )
@ContextConfiguration ( classes = { RootConfiguration.class, WebMvcConfiguration.class } )
@WebAppConfiguration
public class APIPharmacyTest {

    private MockMvc               mvc;

    @Autowired
    private WebApplicationContext context;

    /**
     * Test set up
     */
    @Before
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();
    }

    /**
     * Tests getting a non existent pharmacy and ensures that the correct status
     * is returned.
     *
     * @throws Exception
     */
    @Test
    public void testGetNonExistentPharmacy () throws Exception {
        mvc.perform( get( "/api/v1/pharmacies/-1" ) ).andExpect( status().isNotFound() );
    }

    /**
     * Tests APIPharmacyController
     *
     * @throws Exception
     */
    @Test
    @WithMockUser ( username = "admin", roles = { "ADMIN" } )
    public void testPharmacyAPI () throws Exception {
        // Delete existing test pharmacy
        if ( Pharmacy.getByName( "iTrust Test Pharmacy 2" ) != null ) {
            mvc.perform( delete( "/api/v1/pharmacies/iTrust Test Pharmacy 2" ) );
        }

        // Add a pharmacy via API endpoint
        final PharmacyForm pf = new PharmacyForm();
        pf.setName( "iTrust Test Pharmacy 2" );
        pf.setAddress( "123 Test Street" );
        pf.setAddress2( "Test Building 2" );
        pf.setZip( "11111" );
        pf.setState( "North Carolina" );
        mvc.perform( post( "/api/v1/pharmacies" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( pf ) ) );
        mvc.perform( get( "/api/v1/pharmacies/iTrust Test Pharmacy 2" ) ).andExpect( status().isOk() )
                .andExpect( content().contentType( MediaType.APPLICATION_JSON_UTF8_VALUE ) );

        // Check the backend that the pharmacy was added correctly
        Pharmacy pdb = Pharmacy.getByName( "iTrust Test Pharmacy 2" );
        assertEquals( pf.getName(), pdb.getName() );
        assertEquals( pf.getAddress(), pdb.getAddress() );
        assertEquals( pf.getAddress2(), pdb.getAddress2() );
        assertEquals( pf.getZip(), pdb.getZip() );
        assertEquals( pf.getState(), pdb.getState().getName() );

        // Cannot create same pharmacy twice
        mvc.perform( post( "/api/v1/pharmacies" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( pf ) ) ).andExpect( status().isConflict() );

        // Edit the pharmacy
        pf.setAddress( "2 iTrust Test Street" );
        mvc.perform( put( "/api/v1/pharmacies/iTrust Test Pharmacy 2" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( pf ) ) ).andExpect( status().isOk() )
                .andExpect( content().contentType( MediaType.APPLICATION_JSON_UTF8_VALUE ) );

        // Make sure that the put didn't break anything
        mvc.perform( get( "/api/v1/pharmacies/iTrust Test Pharmacy 2" ) ).andExpect( status().isOk() )
                .andExpect( content().contentType( MediaType.APPLICATION_JSON_UTF8_VALUE ) );

        // Check the backend that the pharmacy was edited correctly
        pdb = Pharmacy.getByName( "iTrust Test Pharmacy 2" );
        assertEquals( pf.getName(), pdb.getName() );
        assertEquals( pf.getAddress(), pdb.getAddress() );
        assertEquals( pf.getAddress2(), pdb.getAddress2() );
        assertEquals( pf.getZip(), pdb.getZip() );
        assertEquals( pf.getState(), pdb.getState().getName() );

        // Editing a non-existent pharmacy should not work
        mvc.perform( put( "/api/v1/pharmacies/iTrust Test Pharmacy 3" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( pf ) ) ).andExpect( status().isNotFound() );

        // Delete the pharmacy
        mvc.perform( delete( "/api/v1/pharmacies/iTrust Test Pharmacy 2" ) ).andExpect( status().isOk() );
        assertNull( Pharmacy.getByName( "iTrust Test Pharmacy 2" ) );
    }

}
