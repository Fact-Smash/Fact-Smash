package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.paulhammant.ngwebdriver.NgWebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.User;

public class PreferencesStepDefs {

    private final String baseUrl          = "http://localhost:8080/iTrust2";

    private final String prescriptionsUrl = "http://localhost:8080/iTrust2/patient/officeVisit/viewPrescriptions";

    private void enterValue ( final String name, final String value ) {
        final WebElement field = CucumberTest.driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }

    protected void attemptLogout () {
        try {
            CucumberTest.driver.get( baseUrl );
            CucumberTest.driver.findElement( By.id( "logout" ) ).click();
        }
        catch ( final Exception e ) {
            // DO NOTHING
        }
    }

    protected void waitForAngular () {
        new NgWebDriver( CucumberTest.driver ).waitForAngularRequestsToFinish();
    }

    @Given ( "A patient and a pharmacy (.+) exist" )
    public void ensureExists ( final String pharmacy ) {
        Pharmacy pharm = Pharmacy.getByName( pharmacy );
        if ( Patient.getPatients().size() == 0 ) {
            final User pat = new User( "AliceThirteen", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                    Role.ROLE_PATIENT, 1 );
            pat.save();
        }
        if ( pharm == null ) {
            pharm = new Pharmacy( pharmacy, "123 road", "", "11111", "North Carolina" );
            pharm.save();
        }
    }

    @Given ( "I have logged in as a patient" )
    public void login () {
        attemptLogout();

        CucumberTest.driver.get( baseUrl );
        waitForAngular();
        enterValue( "username", "AliceThirteen" );
        enterValue( "password", "123456" );
        CucumberTest.driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();
    }

    @When ( "I choose to view the page of prescriptions" )
    public void navigateToManagePharmacies () {
        CucumberTest.driver.get( prescriptionsUrl );
        waitForAngular();
    }

    @When ( "I select (.+) as the default prescription" )
    public void selectPrescriptionType ( final String type ) {
        CucumberTest.driver.findElement( By.id( type ) ).click();
        waitForAngular();
    }

    @When ( "I select (.+) as the default pharmacy" )
    public void selectPharmacy ( final String pharmacy ) {
        final Select drpPharm = new Select( CucumberTest.driver.findElement( By.name( "pharmacy" ) ) );
        waitForAngular();
        drpPharm.selectByVisibleText( pharmacy );
        waitForAngular();
    }

    @When ( "I submit my preferences" )
    public void submit () {
        CucumberTest.driver.findElement( By.name( "submit" ) ).click();
        waitForAngular();
    }

    @Then ( "The preferences are successfully updated" )
    public void preferencesUpdated () {
        waitForAngular();
        assertTrue( CucumberTest.driver.getPageSource().contains( "Preferences saved." ) );
    }
}
