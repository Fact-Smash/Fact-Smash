package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.enums.State;
import edu.ncsu.csc.itrust2.models.persistent.Personnel;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * Step definitions for assigning a pharmacist feature
 *
 * @author Simon Hayes (sbhayes)
 */
public class AssignPharmacistStepDefs extends CucumberTest {

    private final String baseUrl = "http://localhost:8080/iTrust2";

    /**
     * Be sure that unassigned pharmacist and pharmacy are in the system.
     *
     * @param pharmacist
     *            the pharmacist to make sure is in the system.
     * @param pharmacy
     *            the pharmacy to make sure is in the system.
     */
    @Given ( "^A pharmacist (.+) and a pharmacy (.+) are in the system$" )
    public void initialPharma ( final String pharmacist, final String pharmacy ) {
        attemptLogout();

        final User pharmacistUser = new User( pharmacist,
                "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.", Role.ROLE_PHARMACIST, 1 );
        pharmacistUser.save();

        final Personnel ph = new Personnel();
        ph.setSelf( pharmacistUser );
        ph.setFirstName( "Pharma" );
        ph.setLastName( "Cist" );
        ph.setEmail( "pharmacist@fake.com" );
        ph.setAddress1( "1234 Road Dr." );
        ph.setCity( "city" );
        ph.setState( State.AL );
        ph.setZip( "12345" );
        ph.setPhone( "111-222-3333" );
        ph.save();

        driver.get( baseUrl );
        final WebElement username = driver.findElement( By.name( "username" ) );
        username.clear();
        username.sendKeys( "admin" );
        final WebElement password = driver.findElement( By.name( "password" ) );
        password.clear();
        password.sendKeys( "123456" );
        final WebElement submit = driver.findElement( By.className( "btn" ) );
        submit.click();

        CucumberTest.driver.get( "http://localhost:8080/iTrust2/admin/pharmacies" );

        enterValue( "name", pharmacy );
        enterValue( "address", "123 Pharma Sea" );
        enterValue( "address2", "" );
        final Select drpState = new Select( CucumberTest.driver.findElement( By.name( "state" ) ) );
        drpState.selectByVisibleText( "Alaska" );
        enterValue( "zipcode", "77777" );
        CucumberTest.driver.findElement( By.id( "submit" ) ).click();
        waitForAngular();

        attemptLogout();

        assertTrue( Pharmacy.getByName( pharmacy ) != null );
        assertTrue( Personnel.getByName( pharmacist ) != null );
    }

    /**
     * Navigate to assign pharmacist page
     */
    @When ( "^I navigate to the Assign Pharmacist page$" )
    public void assignPharmacistPage () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('assignPharmacist').click();" );
        waitForAngular();
    }

    /**
     * Fill in values for pharmacist and pharmacy. If the value "none" is sent,
     * the page is left as default unselected.
     *
     * @param pharmacist
     *            pharmacist to select from dropdown, or "none"
     * @param pharmacy
     *            pharmacy to select from dropdown, or "none"
     */
    @When ( "^I fill in the values in the Assign Pharmacist form (.+) and (.+)$" )
    public void fillFields ( final String pharmacist, final String pharmacy ) {
        waitForAngular();
        if ( !pharmacist.equals( "none" ) ) {
            final Select pharmacists = new Select( driver.findElement( By.id( "pharmacist" ) ) );
            pharmacists.selectByVisibleText( pharmacist );
        }
        if ( !pharmacy.equals( "none" ) ) {
            final Select pharmacys = new Select( driver.findElement( By.id( "pharmacy" ) ) );
            pharmacys.selectByVisibleText( pharmacy );
        }

        driver.findElement( By.id( "submit" ) ).click();

    }

    /**
     * Make sure user is assigned.
     *
     * @param pharmacist
     *            pharmacist that should be assigned.
     * @param pharmacy
     *            pharmacy that should be assigned.
     */
    @Then ( "^The pharmacist (.+) is assigned to the pharmacy (.+)$" )
    public void assignedSuccessfully ( final String pharmacist, final String pharmacy ) {
        assertTrue( driver.getPageSource().contains( "Pharmacist assigned successfully." ) );
        final Personnel assignedPharmacist = Personnel.getByName( pharmacist );
        assertEquals( pharmacy, assignedPharmacist.getHospitalId() );
    }

    /**
     * Make sure user is not assigned.
     *
     * @param pharmacist
     *            pharmacist that should not be assigned.
     * @param pharmacy
     *            pharmacy that should not be assigned.
     */
    @Then ( "^The pharmacist (.+) is not assigned to the pharmacy (.+)$" )
    public void assignedUnsuccessfully ( final String pharmacist, final String pharmacy ) {
        final Personnel assignedPharmacist = Personnel.getByName( pharmacist );
        assertNotEquals( pharmacy, assignedPharmacist.getHospitalId() );
    }

    /**
     * Helper method for entering values into a field.
     *
     * @param name
     *            name of the field to enter values into
     * @param value
     *            value to enter into the field.
     */
    private void enterValue ( final String name, final String value ) {
        final WebElement field = CucumberTest.driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }
}
