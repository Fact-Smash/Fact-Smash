package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.paulhammant.ngwebdriver.NgWebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;

public class PharmacyStepDefs {

    private final String baseUrl     = "http://localhost:8080/iTrust2";

    private final String pharmacyUrl = "http://localhost:8080/iTrust2/admin/pharmacies";

    private void enterValue ( final String name, final String value ) {
        final WebElement field = CucumberTest.driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }

    protected void attemptLogout () {
        try {
            CucumberTest.driver.get( baseUrl );
            CucumberTest.driver.findElement( By.id( "logout" ) ).click();
        }
        catch ( final Exception e ) {
            // DO NOTHING
        }
    }

    @Given ( "^The pharmacy (.+) does not exist$" )
    public void ensureCreation ( final String pharmaName ) {
        final Pharmacy pharma = Pharmacy.getByName( pharmaName );
        if ( pharma != null ) {
            pharma.delete();
        }

    }

    @Given ( "^I have logged in with the following username: (.+)$" )
    public void login ( final String username ) {

        attemptLogout();

        CucumberTest.driver.get( baseUrl );

        enterValue( "username", username );
        enterValue( "password", "123456" );
        CucumberTest.driver.findElement( By.className( "btn" ) ).click();
    }

    @When ( "^I navigate to the manage pharmacies page$" )
    public void navigateToManagePharmacies () {
        CucumberTest.driver.get( pharmacyUrl );
    }

    @When ( "^I fill out the form with valid name (.+) address (.+) address2 (.+) state (.+) and zip code (.+)$" )
    public void fillOutPharmacySheet ( final String name, final String address, final String address2,
            final String state, final String zip ) {
        enterValue( "name", name );
        enterValue( "address", address );
        enterValue( "address2", address2 );
        final Select drpState = new Select( CucumberTest.driver.findElement( By.name( "state" ) ) );
        drpState.selectByVisibleText( state );
        enterValue( "zipcode", zip );
        CucumberTest.driver.findElement( By.id( "submit" ) ).click();
        waitForAngular();
    }

    protected void waitForAngular () {
        new NgWebDriver( CucumberTest.driver ).waitForAngularRequestsToFinish();
    }

    @Then ( "^the pharmacy with name (.+) is successfully added$" )
    public void pharmacyAdded ( final String name ) {
        assertNotNull( Pharmacy.getByName( name ) );
    }

    @Then ( "^the pharmacy with name (.+) is not added$" )
    public void pharmacyNotAdded ( final String name ) {
        assertNull( Pharmacy.getByName( name ) );
    }

    @When ( "^I delete the pharmacy named (.+)$" )
    public void deletePharmacy ( final String name ) {
        CucumberTest.driver.findElement( By.name( "deletePharmacy" ) ).click();
        waitForAngular();
    }

    @Then ( "^the pharmacy named (.+) successfully deleted$" )
    public void noPharmacies ( final String name ) {
        assertNull( Pharmacy.getByName( name ) );
    }

    @When ( "^I add a pharmacy named (.+)$" )
    public void addPharmacy ( final String name ) {
        fillOutPharmacySheet( "new pharmacy to add", "address123", "23", "Arkansas", "12355" );
        assertTrue( Pharmacy.getPharmacies().size() > 0 );

    }

}
