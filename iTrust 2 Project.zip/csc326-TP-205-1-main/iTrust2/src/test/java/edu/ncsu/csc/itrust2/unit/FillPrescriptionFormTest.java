package edu.ncsu.csc.itrust2.unit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;

import org.junit.Test;

import edu.ncsu.csc.itrust2.forms.admin.DrugForm;
import edu.ncsu.csc.itrust2.forms.hcp.PrescriptionForm;
import edu.ncsu.csc.itrust2.forms.personnel.FillPrescriptionForm;
import edu.ncsu.csc.itrust2.models.persistent.Prescription;

/**
 * Tests the constructors and methods of FillPrescriptionForm.
 *
 * @author twzheng
 *
 */
public class FillPrescriptionFormTest {

    /**
     * Test the FillPrescriptionForm class.
     */
    @Test
    public void testFillPrescriptionForm () throws ParseException {

        // Create drug for testing
        final DrugForm drugForm = new DrugForm();
        drugForm.setCode( "0000-0000-20" );
        drugForm.setName( "TEST" );
        drugForm.setDescription( "DESC" );

        // Create prescription for testing
        final PrescriptionForm form1 = new PrescriptionForm();
        form1.setDrug( drugForm.getCode() );
        form1.setDosage( 100 );
        form1.setRenewals( 12 );
        form1.setPatient( "api_test_patient" );
        form1.setStartDate( "2009-10-10" ); // 10/10/2009
        form1.setEndDate( "2010-10-10" ); // 10/10/2010
        form1.setLocation( "pharmacy" );
        form1.setWantsGeneric( false );

        final Prescription testPrescription = new Prescription( form1 );

        // Default Settings
        FillPrescriptionForm fpf = new FillPrescriptionForm( testPrescription );
        assertFalse( fpf.getFilled() );
        assertFalse( fpf.getIsGeneric() );

        // Set the status
        testPrescription.setFilled( true );
        testPrescription.setIsGeneric( true );
        fpf = new FillPrescriptionForm( testPrescription );
        assertTrue( fpf.getFilled() );
        assertTrue( fpf.getIsGeneric() );
    }
}
