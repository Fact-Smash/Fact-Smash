package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.paulhammant.ngwebdriver.NgWebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.enums.HouseholdSmokingStatus;
import edu.ncsu.csc.itrust2.models.enums.PatientSmokingStatus;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.persistent.Drug;
import edu.ncsu.csc.itrust2.models.persistent.OfficeVisit;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * Class to test sending prescriptions through documenting an office visit. Uses
 * and adjusts code from Prescription, Preferences, and DocumentOfficeVisit
 * StepDefs.
 *
 * @author Simon Hayes (sbhayes)
 */
public class SendPrescriptionStepDefs {

    /** Base URL of the project. */
    private final String baseUrl          = "http://localhost:8080/iTrust2";
    /** Base URL of the prescription page. */
    private final String prescriptionsUrl = "http://localhost:8080/iTrust2/patient/officeVisit/viewPrescriptions";

    /**
     * Makes sure that a patient to make an office for and a pharmacy to send
     * prescriptions to exists.
     *
     * @param pharmacy
     *            the pharmacy to make sure is in the system.
     */
    @Given ( "^A patient and the pharmacy (.+) exist$" )
    public void settingUpPatients ( final String pharmacy ) {
        Pharmacy pharm = Pharmacy.getByName( pharmacy );
        if ( Patient.getPatients().size() == 0 ) {
            final User pat = new User( "AliceThirteen", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                    Role.ROLE_PATIENT, 1 );
            pat.save();
        }
        if ( pharm == null ) {
            pharm = new Pharmacy( pharmacy, "123 road", "", "11111", "North Carolina" );
            pharm.save();
        }
    }

    /**
     * Set the patient's preferences for type and pharmacy
     *
     * @param prefType
     *            the preferred type (or none)
     * @param prefPharm
     *            the preferred pharmacy (or none)
     */
    @Given ( "^The patient prefers type (.+) and pharmacy (.+)$" )
    public void settingPreferences ( final String prefType, final String prefPharm ) {
        attemptLogout();

        CucumberTest.driver.get( baseUrl );
        waitForAngular();
        enterValue( "username", "AliceThirteen" );
        enterValue( "password", "123456" );
        CucumberTest.driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();

        CucumberTest.driver.get( prescriptionsUrl );
        waitForAngular();

        CucumberTest.driver.findElement( By.id( prefType ) ).click();
        waitForAngular();

        final Select drpPharm = new Select( CucumberTest.driver.findElement( By.name( "pharmacy" ) ) );
        waitForAngular();
        drpPharm.selectByVisibleText( prefPharm );
        waitForAngular();

        CucumberTest.driver.findElement( By.name( "submit" ) ).click();
        waitForAngular();
    }

    /**
     * Logs in as an HCP in order to create an office visit.
     */
    @Given ( "^I have logged in as an HCP$" )
    public void hcpLogin () {
        attemptLogout();

        CucumberTest.driver.get( baseUrl );
        waitForAngular();
        enterValue( "username", "hcp" );
        enterValue( "password", "123456" );
        CucumberTest.driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();
    }

    /**
     * Goes to the document office visit page.
     */
    @When ( "^I choose to document an office visit$" )
    public void docOfficeVisit () {
        ( (JavascriptExecutor) CucumberTest.driver )
                .executeScript( "document.getElementById('documentOfficeVisit').click();" );
        waitForAngular();
    }

    /**
     * Selects the existing patient with preferences and the general checkup
     * button.
     */
    @When ( "^I select general checkup and the patient$" )
    public void startCheckup () {
        waitForAngular();
        final WebElement patient = CucumberTest.driver
                .findElement( By.cssSelector( "input[value=\"AliceThirteen\"]" ) );
        patient.click();

        waitForAngular();
        final WebElement type = CucumberTest.driver.findElement( By.name( "GENERAL_CHECKUP" ) );
        type.click();
    }

    /**
     * Makes sure that the user's default preferences are loaded in the dropdown
     * boxes. If they have no selected preferences, nothing is preloaded.
     *
     * @param prefType
     *            the type to make sure is preload
     * @param prefPharm
     *            the pharmacy that should be preloaded
     */
    @Then ( "^The preferences (.+) and (.+) will be loaded$" )
    public void preferencesLoaded ( final String prefType, final String prefPharm ) {
        waitForAngular();
        final Select type = new Select( CucumberTest.driver.findElement( By.name( "typeEntry" ) ) );
        if ( prefType.equalsIgnoreCase( "none" ) ) {
            assertEquals( "", type.getFirstSelectedOption().getText().trim() );
            // If nothing is selected this is correct, but just select one to
            // allow for prescription entry.
            type.selectByVisibleText( "Name Brand" );
        }
        else if ( prefType.equalsIgnoreCase( "generic" ) ) {
            assertEquals( "Generic", type.getFirstSelectedOption().getText().trim() );
        }
        else {
            assertEquals( "Name Brand", type.getFirstSelectedOption().getText().trim() );
        }

        final Select location = new Select( CucumberTest.driver.findElement( By.name( "locationEntry" ) ) );
        if ( prefPharm.equalsIgnoreCase( "none" ) ) {
            assertEquals( "", location.getFirstSelectedOption().getText().trim() );
            // If nothing is selected this is correct, but just select one to
            // allow for prescription entry.
            final String pharmacyName = Pharmacy.getPharmacies().get( 0 ).getName();
            location.selectByVisibleText( pharmacyName );
        }
        else {
            assertEquals( prefPharm, location.getFirstSelectedOption().getText().trim() );
        }
    }

    /**
     * Make sure that a prescription can be added to the office visit.
     */
    @Then ( "^A prescription can be added$" )
    public void canAddPrescription () {
        waitForAngular();

        enterValue( "dosageEntry", "5" );
        fillInDate( "startEntry", "5/5/2020" );
        fillInDate( "endEntry", "10/5/2020" );
        enterValue( "renewalEntry", "5" );
        selectName( Drug.getAll().get( 0 ).getName() );
        CucumberTest.driver.findElement( By.name( "fillPrescription" ) ).click();
        assertEquals( "", CucumberTest.driver.findElement( By.name( "errorMsg" ) ).getText() );
    }

    /**
     * Creates a generic office visit for the patient to be selected. Uses code
     * from DocumentOfficeVisitStepDefs
     */
    @Given ( "^An office visit exists for the patient$" )
    public void addGenericOfficeVisit () {
        attemptLogout();

        CucumberTest.driver.get( baseUrl );
        waitForAngular();
        enterValue( "username", "hcp" );
        enterValue( "password", "123456" );
        CucumberTest.driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();

        ( (JavascriptExecutor) CucumberTest.driver )
                .executeScript( "document.getElementById('documentOfficeVisit').click();" );
        waitForAngular();

        final WebElement notes = CucumberTest.driver.findElement( By.name( "notes" ) );
        notes.clear();
        notes.sendKeys( "Patient appears pretty much alive" );

        final WebElement patient = CucumberTest.driver
                .findElement( By.cssSelector( "input[value=\"AliceThirteen\"]" ) );
        patient.click();

        waitForAngular();
        final WebElement type = CucumberTest.driver.findElement( By.name( "GENERAL_CHECKUP" ) );
        type.click();

        final WebElement hospital = CucumberTest.driver.findElement( By.name( "hospital" ) );
        hospital.click();

        fillInDateTime( "date", "12/19/2027", "time", "9:30 AM" );

        waitForAngular();

        final WebElement heightElement = CucumberTest.driver.findElement( By.name( "height" ) );
        heightElement.clear();
        heightElement.sendKeys( "120" );

        final WebElement weightElement = CucumberTest.driver.findElement( By.name( "weight" ) );
        weightElement.clear();
        weightElement.sendKeys( "120" );

        final WebElement systolicElement = CucumberTest.driver.findElement( By.name( "systolic" ) );
        systolicElement.clear();
        systolicElement.sendKeys( "100" );

        final WebElement diastolicElement = CucumberTest.driver.findElement( By.name( "diastolic" ) );
        diastolicElement.clear();
        diastolicElement.sendKeys( "100" );

        final WebElement hdlElement = CucumberTest.driver.findElement( By.name( "hdl" ) );
        hdlElement.clear();
        hdlElement.sendKeys( "90" );

        final WebElement ldlElement = CucumberTest.driver.findElement( By.name( "ldl" ) );
        ldlElement.clear();
        ldlElement.sendKeys( "100" );

        final WebElement triElement = CucumberTest.driver.findElement( By.name( "tri" ) );
        triElement.clear();
        triElement.sendKeys( "100" );

        final WebElement houseSmokeElement = CucumberTest.driver.findElement(
                By.cssSelector( "input[value=\"" + HouseholdSmokingStatus.NONSMOKING.toString() + "\"]" ) );
        houseSmokeElement.click();

        final WebElement patientSmokeElement = CucumberTest.driver
                .findElement( By.cssSelector( "input[value=\"" + PatientSmokingStatus.NEVER.toString() + "\"]" ) );
        patientSmokeElement.click();

        CucumberTest.driver.findElement( By.name( "submit" ) ).click();
    }

    /**
     * Moves to the edit office visit page.
     */
    @When ( "^I choose to edit an office visit$" )
    public void chooseEditOffice () {
        ( (JavascriptExecutor) CucumberTest.driver )
                .executeScript( "document.getElementById('editOfficeVisit').click();" );
        waitForAngular();
    }

    /**
     * Selects the office visit from the edit office visit page.
     */
    @When ( "^I select the office visit belonging to the patient$" )
    public void selectOfficeVisit () {
        waitForAngular();
        final List<OfficeVisit> visit = OfficeVisit.getForPatient( "AliceThirteen" );
        final Long visitId = visit.get( visit.size() - 1 ).getId();

        final WebElement patient = CucumberTest.driver
                .findElement( By.cssSelector( "input[value=\"" + visitId + "\"]" ) );
        patient.click();
    }

    /**
     * Helper method for entering a value into a field.
     *
     * @param name
     *            name of the field to enter values into
     * @param value
     *            value to enter into the field
     */
    private void enterValue ( final String name, final String value ) {
        final WebElement field = CucumberTest.driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }

    /**
     * Helper method for logging out with the current user (if one is logged in)
     */
    protected void attemptLogout () {
        try {
            CucumberTest.driver.get( baseUrl );
            CucumberTest.driver.findElement( By.id( "logout" ) ).click();
        }
        catch ( final Exception e ) {
            // DO NOTHING
        }
    }

    /**
     * Helper method to make sure angular operations are done before moving on.
     */
    protected void waitForAngular () {
        new NgWebDriver( CucumberTest.driver ).waitForAngularRequestsToFinish();
    }

    /**
     * Helper method, fills in values specifically for dates.
     *
     * @param dateField
     *            the date field to enter into
     * @param date
     *            the date to enter in the field as MM/DD/YYYY
     */
    private void fillInDate ( final String dateField, final String date ) {
        CucumberTest.driver.findElement( By.name( dateField ) ).clear();
        final WebElement dateElement = CucumberTest.driver.findElement( By.name( dateField ) );
        dateElement.sendKeys( date.replace( "/", "" ) );
    }

    /**
     * Fills in the time field with the specified time.
     *
     * @param time
     *            The time to enter.
     */
    private void fillInTime ( final String timeField, String time ) {
        // Zero-pad the time for entry
        if ( time.length() == 7 ) {
            time = "0" + time;
        }

        CucumberTest.driver.findElement( By.name( timeField ) ).clear();
        final WebElement timeElement = CucumberTest.driver.findElement( By.name( timeField ) );
        timeElement.sendKeys( time.replace( ":", "" ).replace( " ", "" ) );
    }

    /**
     * Helper method, selects something from a selection of radio buttons by a
     * specified name.
     *
     * @param name
     *            the name of the item to select in the radio button section
     */
    private void selectName ( final String name ) {
        final WebElement element = CucumberTest.driver.findElement( By.cssSelector( "input[name='" + name + "']" ) );
        element.click();
    }

    /**
     * Fills in the date and time fields with the specified date and time.
     * Reused from DocumentOfficeVistStepDefs.
     *
     * @param date
     *            The date to enter.
     * @param time
     *            The time to enter.
     */
    private void fillInDateTime ( final String dateField, final String date, final String timeField,
            final String time ) {
        fillInDate( dateField, date );
        fillInTime( timeField, time );
    }

}
