package edu.ncsu.csc.itrust2.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.text.ParseException;

import org.junit.Test;

import edu.ncsu.csc.itrust2.forms.hcp_patient.PatientPreferenceForm;
import edu.ncsu.csc.itrust2.models.enums.PrescriptionPreference;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.enums.State;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * Tests the constructors and methods of PatientPreferenceForm.
 *
 * @author twzheng
 *
 */
public class PatientPreferenceFormTest {

    /**
     * Test the PatientPreferenceForm class.
     */
    @Test
    public void testPatientPreferenceForm () throws ParseException {
        final Pharmacy testPharmacy = new Pharmacy();
        testPharmacy.setName( "Test Pharmacy" );
        testPharmacy.setAddress( "123 Test Road" );
        testPharmacy.setState( State.NC );
        testPharmacy.setZip( "27040" );

        // Construct from an existing Patient
        final Patient testPatient = new Patient();
        testPatient.setSelf( new User( "preferenceTestPatient", "123456", Role.ROLE_PATIENT, 1 ) );

        // Default Preferences
        PatientPreferenceForm ppf = new PatientPreferenceForm( testPatient );
        assertNull( ppf.getPreferredPharmacy() );
        assertEquals( "None", ppf.getPreferredPrescriptionType() );

        // Set the preferences
        testPatient.setPreferredPharmacy( testPharmacy );
        testPatient.setPreferredPrescriptionType( PrescriptionPreference.Brand );
        ppf = new PatientPreferenceForm( testPatient );
        assertEquals( "Test Pharmacy", ppf.getPreferredPharmacy() );
        assertEquals( "Brand", ppf.getPreferredPrescriptionType() );
    }
}
