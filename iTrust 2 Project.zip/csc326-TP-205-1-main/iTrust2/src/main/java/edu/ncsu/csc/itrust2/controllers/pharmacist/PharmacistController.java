  
package edu.ncsu.csc.itrust2.controllers.pharmacist;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PharmacistController {
    /**
     * Returns the Landing screen for the PHARMACIST
     *
     * @param model
     *            Data from the front end
     * @return The page to display
     */
    @RequestMapping ( value = "pharmacist/index" )
    @PreAuthorize ( "hasRole('ROLE_PHARMACIST')" )
    public String index ( final Model model ) {
        return edu.ncsu.csc.itrust2.models.enums.Role.ROLE_PHARMACIST.getLanding();
    }
    
    /**
     * manage pharmacies
     *
     * @param model
     *            data for front end
     * @return mapping
     */
    @RequestMapping ( value = "pharmacist/fillPrescriptions" )
    @PreAuthorize ( "hasRole('ROLE_PHARMACIST')" )
    public String fillPrescriptions ( final Model model ) {
        return "/pharmacist/fillPrescriptions";
    }

}
