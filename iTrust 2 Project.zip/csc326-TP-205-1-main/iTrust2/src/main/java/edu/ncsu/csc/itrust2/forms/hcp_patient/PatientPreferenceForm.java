package edu.ncsu.csc.itrust2.forms.hcp_patient;

import org.hibernate.validator.constraints.Length;

import edu.ncsu.csc.itrust2.models.enums.PrescriptionPreference;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;

/**
 * Form for user to fill out set their preferences.
 *
 * @author twzheng
 *
 */
public class PatientPreferenceForm {

    /**
     * Populate the patient preference form from a patient object
     *
     * @param patient
     *            the patient object to set the form with
     */
    public PatientPreferenceForm ( final Patient patient ) {
        if ( null == patient ) {
            return; /* Nothing to do here */
        }
        self = patient.getSelf().getUsername();
        final Pharmacy p = patient.getPreferredPharmacy();
        if ( p != null ) {
            setPreferredPharmacy( p.getId() );
        }
        final PrescriptionPreference type = patient.getPreferredPrescriptionType();
        if ( type != null ) {
            setPreferredPrescriptionType( type.toString() );
        }
        else {
            setPreferredPrescriptionType( "" );
        }
    }

    /** The username of the patient **/
    @Length ( max = 20 )
    private String self;

    /** The patient's preferred pharmacy **/
    @Length ( max = 100 )
    private String preferredPharmacy;

    /** The patient's preferred prescription type **/
    @Length ( max = 10 )
    private String preferredPrescriptionType;

    /**
     * Empty Constructor.
     */
    public PatientPreferenceForm () {
    }

    /**
     * Get the username of the patient
     *
     * @return the username of the patient
     */
    public String getSelf () {
        return self;
    }

    /**
     * Set the username of the patient
     *
     * @param self
     *            the username of the patient
     */
    public void setSelf ( final String self ) {
        this.self = self;
    }

    /**
     * Get the preferred pharmacy of the patient
     *
     * @return the preferred pharmacy of the patient
     */
    public String getPreferredPharmacy () {
        return preferredPharmacy;
    }

    /**
     * Set the preferred pharmacy of the patient
     *
     * @param preferredPharmacy
     *            the preferred pharmacy of the patient
     */
    public void setPreferredPharmacy ( final String preferredPharmacy ) {
        this.preferredPharmacy = preferredPharmacy;
    }

    /**
     * Get the preferred prescription type of the patient
     *
     * @return the preferred prescription type of the patient
     */
    public String getPreferredPrescriptionType () {
        return preferredPrescriptionType;
    }

    /**
     * Set the preferred prescription type of the patient
     *
     * @param preferredPrescriptionType
     *            the preferred prescription type of the patient
     */
    public void setPreferredPrescriptionType ( final String preferredPrescriptionType ) {
        this.preferredPrescriptionType = preferredPrescriptionType;
    }

}
