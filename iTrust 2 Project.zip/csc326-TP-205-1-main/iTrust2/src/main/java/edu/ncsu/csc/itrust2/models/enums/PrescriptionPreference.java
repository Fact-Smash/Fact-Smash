package edu.ncsu.csc.itrust2.models.enums;

/**
 * Enum for the different prescription preferences
 *
 * @author Jimmy Zheng (twzheng)
 *
 */
public enum PrescriptionPreference {
    /**
     * No Preferences
     */
    None,
    /**
     * Prefers Brand Prescription
     */
    Brand,
    /**
     * Prefers Generic Prescription
     */
    Generic
}
