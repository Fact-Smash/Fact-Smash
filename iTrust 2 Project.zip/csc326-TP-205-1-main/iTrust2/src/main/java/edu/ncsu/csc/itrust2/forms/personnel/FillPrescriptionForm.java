package edu.ncsu.csc.itrust2.forms.personnel;

import edu.ncsu.csc.itrust2.models.persistent.Prescription;

/**
 * A form used for REST API communication to fill prescriptions.
 *
 * @author Jimmy Zheng
 *
 */
public class FillPrescriptionForm {

    private Long    id;
    private boolean filled;
    private boolean isGeneric;

    /**
     * Empty constructor for filling in fields without a Prescription object.
     */
    public FillPrescriptionForm () {
    }

    /**
     * Construct the Fill Prescription form based on the given Prescription
     * object
     *
     * @param prescription
     *            the prescription object
     */
    public FillPrescriptionForm ( Prescription prescription ) {
        setId( prescription.getId() );
        setFilled( prescription.getFilled() );
        setIsGeneric( prescription.getIsGeneric() );
    }

    /**
     * Returns the id associated with the Prescription.
     *
     * @return the prescription id
     */
    public Long getId () {
        return id;
    }

    /**
     * Sets the Prescription's unique id.
     *
     * @param id
     *            the prescription id
     */
    public void setId ( Long id ) {
        this.id = id;
    }

    /**
     * Returns whether the prescription is filled.
     *
     * @return the filled status of the prescription
     */
    public boolean getFilled () {
        return filled;
    }

    /**
     * Set whether the prescription is filled.
     *
     * @param isFilled
     *            the filled status to set
     */
    public void setFilled ( final boolean isFilled ) {
        this.filled = isFilled;
    }

    /**
     * Returns whether the filled prescription is generic.
     *
     * @return the generic status of the prescription
     */
    public boolean getIsGeneric () {
        return isGeneric;
    }

    /**
     * Sets whether the filled prescription is generic.
     *
     * @param isGeneric
     *            the generic status to set
     */
    public void setIsGeneric ( final boolean isGeneric ) {
        this.isGeneric = isGeneric;
    }
}
