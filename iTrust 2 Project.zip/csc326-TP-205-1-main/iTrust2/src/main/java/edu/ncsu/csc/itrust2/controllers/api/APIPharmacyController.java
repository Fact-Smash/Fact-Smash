package edu.ncsu.csc.itrust2.controllers.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.itrust2.forms.admin.PharmacyForm;
import edu.ncsu.csc.itrust2.models.enums.TransactionType;
import edu.ncsu.csc.itrust2.models.persistent.Personnel;
import edu.ncsu.csc.itrust2.models.persistent.Pharmacy;
import edu.ncsu.csc.itrust2.models.persistent.Prescription;
import edu.ncsu.csc.itrust2.utils.LoggerUtil;

/**
 * Class that provides REST API endpoints for the Pharmacy model. In all
 * requests made to this controller, the {id} provided is a String that is the
 * name of the pharmacy desired.
 *
 * @author twzheng
 *
 */
@RestController
@SuppressWarnings ( { "unchecked", "rawtypes" } )
public class APIPharmacyController extends APIController {

    /**
     * Retrieves a list of all Pharmacies in the database
     *
     * @return list of pharmacies
     */
    @GetMapping ( BASE_PATH + "/pharmacies" )
    public List<Pharmacy> getPharmacies () {
        return Pharmacy.getPharmacies();
    }

    /**
     * Retrieves the Pharmacy specified by the name provided
     *
     * @param id
     *            The name of the pharmacy
     * @return response
     */
    @GetMapping ( BASE_PATH + "/pharmacies/{id}" )
    public ResponseEntity getPharmacy ( @PathVariable ( "id" ) final String id ) {
        final Pharmacy pharmacy = Pharmacy.getByName( id );
        if ( null != pharmacy ) {
            LoggerUtil.log( TransactionType.VIEW_PHARMACY, LoggerUtil.currentUser() );
        }
        return null == pharmacy
                ? new ResponseEntity( errorResponse( "No pharmacy found for name " + id ), HttpStatus.NOT_FOUND )
                : new ResponseEntity( pharmacy, HttpStatus.OK );
    }

    /**
     * Creates a new Pharmacy from the RequestBody provided.
     *
     * @param pharmacyForm
     *            The Pharmacy to be validated and saved to the database.
     * @return response
     */
    @PostMapping ( BASE_PATH + "/pharmacies" )
    @PreAuthorize ( "hasRole('ROLE_ADMIN') " )
    public ResponseEntity createPharmacy ( @RequestBody final PharmacyForm pharmacyForm ) {
        final Pharmacy pharmacy = new Pharmacy( pharmacyForm );
        if ( null != Pharmacy.getByName( pharmacy.getName() ) ) {
            return new ResponseEntity(
                    errorResponse( "Pharmacy with the name " + pharmacy.getName() + " already exists" ),
                    HttpStatus.CONFLICT );
        }
        try {
            pharmacy.save();
            LoggerUtil.log( TransactionType.CREATE_PHARMACY, LoggerUtil.currentUser() );
            return new ResponseEntity( pharmacy, HttpStatus.OK );
        }
        catch ( final Exception e ) {
            return new ResponseEntity( errorResponse( "Error occured while validating or saving " + pharmacy.toString()
                    + " because of " + e.getMessage() ), HttpStatus.BAD_REQUEST );
        }

    }

    /**
     * Updates the pharmacy with the name provided by overwriting it with the
     * new Pharmacy provided.
     *
     * @param id
     *            Name of the pharmacy to update
     * @param pharmacyForm
     *            The new pharmacy to save to this name
     * @return response
     */
    @PutMapping ( BASE_PATH + "/pharmacies/{id}" )
    @PreAuthorize ( "hasRole('ROLE_ADMIN') " )
    public ResponseEntity updatePharmacy ( @PathVariable final String id,
            @RequestBody final PharmacyForm pharmacyForm ) {
        final Pharmacy pharmacy = new Pharmacy( pharmacyForm );
        final Pharmacy dbPharmacy = Pharmacy.getByName( id );
        if ( null == dbPharmacy ) {
            return new ResponseEntity( errorResponse( "No pharmacy found for name " + id ), HttpStatus.NOT_FOUND );
        }
        try {
            pharmacy.save(); /* Will overwrite existing request */
            if ( !pharmacy.getName().equals( id ) ) {
                // If we are editing the name, we have to delete the old record,
                // because name is used as the primary key in hibernate.
                dbPharmacy.delete();
            }
            LoggerUtil.log( TransactionType.EDIT_PHARMACY, LoggerUtil.currentUser() );
            return new ResponseEntity( pharmacy, HttpStatus.OK );
        }
        catch ( final Exception e ) {
            return new ResponseEntity( errorResponse( "Could not update " + id + " because of " + e.getMessage() ),
                    HttpStatus.BAD_REQUEST );
        }
    }

    /**
     * Deletes the pharmacy with the id matching the given id. Requires admin
     * permissions.
     *
     * @param id
     *            the id of the pharmacy to delete
     * @return the id of the deleted pharmacy
     */
    @PreAuthorize ( "hasRole('ROLE_ADMIN')" )
    @DeleteMapping ( BASE_PATH + "/pharmacies/{id}" )
    public ResponseEntity deletePharmacy ( @PathVariable final String id ) {
        try {
            final Pharmacy pharmacy = Pharmacy.getByName( id );
            if ( pharmacy == null ) {
                LoggerUtil.log( TransactionType.DELETE_PHARMACY, LoggerUtil.currentUser(),
                        "Could not find pharmacy with id " + id );
                return new ResponseEntity( errorResponse( "No pharmacy found with name " + id ), HttpStatus.NOT_FOUND );
            }
            pharmacy.delete();
            LoggerUtil.log( TransactionType.DELETE_PHARMACY, LoggerUtil.currentUser(),
                    "Deleted pharmacy with name " + pharmacy.getName() );
            return new ResponseEntity( pharmacy, HttpStatus.OK );
        }
        catch ( final Exception e ) {
            LoggerUtil.log( TransactionType.DELETE_PHARMACY, LoggerUtil.currentUser(), "Failed to delete pharmacy" );
            return new ResponseEntity( errorResponse( "Could not delete pharmacy: " + e.getMessage() ),
                    HttpStatus.BAD_REQUEST );
        }
    }

    /**
     * Gets the list of prescriptions that belong to the passed pharmacy
     *
     * @param id
     *            the name of the pharmacy
     * @return a list of prescriptions that belong to the passed pharmacy
     */
    @PreAuthorize ( "hasRole('ROLE_PHARMACIST')" )
    @GetMapping ( BASE_PATH + "/pharmacies/{id}/prescriptions" )
    public ResponseEntity getPrescriptions ( @PathVariable final String id ) {
        if ( Personnel.getByName( LoggerUtil.currentUser() ).getHospitalId() == null
                || !Personnel.getByName( LoggerUtil.currentUser() ).getHospitalId().equals( id ) ) {
            LoggerUtil.log( TransactionType.VIEW_PHARMACY_PRESCRIPTIONS, LoggerUtil.currentUser(),
                    "Ineligable user attempted to view prescriptions for pharmacy with name " + id );
            return new ResponseEntity( errorResponse( "This pharmacist doesn't work at the given pharmacy" ),
                    HttpStatus.BAD_REQUEST );
        }

        if ( Pharmacy.getByName( id ) == null ) {
            LoggerUtil.log( TransactionType.VIEW_PHARMACY_PRESCRIPTIONS, LoggerUtil.currentUser(),
                    "Could not find pharmacy with name " + id );
            return new ResponseEntity( errorResponse( "The given pharmacy doesn't exist" ), HttpStatus.BAD_REQUEST );
        }
        LoggerUtil.log( TransactionType.VIEW_PHARMACY_PRESCRIPTIONS, LoggerUtil.currentUser(),
                "Prescriptions for pharmacy with name " + id + " were viewed" );
        return new ResponseEntity( Prescription.getForPharmacy( id ), HttpStatus.OK );
    }
}
