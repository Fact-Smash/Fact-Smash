package edu.ncsu.csc.itrust2.models.persistent;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.criterion.Criterion;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import edu.ncsu.csc.itrust2.forms.admin.PharmacyForm;
import edu.ncsu.csc.itrust2.models.enums.State;

@Entity
@Table ( name = "Pharmacies" )
public class Pharmacy extends DomainObject<Pharmacy> implements Serializable {
    /**
     * Used for serializing the object.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Construct a Pharmacy object from the given Pharmacy object
     *
     * @param pf
     *            a PharmacyForm to convert into a Pharmacy
     */
    public Pharmacy ( final PharmacyForm pf ) {
        setName( pf.getName() );
        setAddress( pf.getAddress() );
        setAddress2( pf.getAddress2() );
        setZip( pf.getZip() );
        setState( State.parse( pf.getState() ) );
    }

    /**
     * Construct a Pharmacy object from all fields
     *
     * @param name
     *            name of the Pharmacy
     * @param address
     *            address of the Pharmacy
     * @param address2
     *            address 2 of the Pharmacy
     * @param zip
     *            zip code of the Pharmacy
     * @param state
     *            state of the Pharmacy
     */
    public Pharmacy ( String name, String address, String address2, String zip, String state ) {
        setName( name );
        setAddress( address );
        setAddress2( address2 );
        setZip( zip );
        setState( State.parse( state ) );
    }

    /**
     * Retrieve a Pharmacy from the database or in-memory cache by name.
     *
     * @param name
     *            Name of the Pharmacy to retrieve
     * @return The Pharmacy found, or null if none was found.
     */
    public static Pharmacy getByName ( final String name ) {
        try {
            return getWhere( eqList( "name", name ) ).get( 0 );
        }
        catch ( final Exception e ) {
            return null;
        }
    }

    /**
     * Retrieve all matching Pharmacies from the database that match a where
     * clause provided.
     *
     * @param where
     *            List of Criterion to and together and search for records by
     * @return The matching Pharmacies
     */
    @SuppressWarnings ( "unchecked" )
    private static List<Pharmacy> getWhere ( final List<Criterion> where ) {
        return (List<Pharmacy>) getWhere( Pharmacy.class, where );
    }

    /**
     * Retrieve all Pharmacies from the database
     *
     * @return Pharmacies found
     */
    @SuppressWarnings ( "unchecked" )
    public static List<Pharmacy> getPharmacies () {
        return (List<Pharmacy>) getAll( Pharmacy.class );
    }

    /**
     * Construct an empty Pharmacy record. Used for Hibernate.
     */
    public Pharmacy () {
    }

    /**
     * Name of the Pharamcy
     */
    @NotEmpty
    @Length ( max = 100 )
    @Id
    private String name;

    /**
     * Address of the Pharmacy
     */
    @NotEmpty
    @Length ( max = 100 )
    private String address;

    /**
     * Address 2 of the Pharmacy
     */
    @Length ( max = 100 )
    private String address2;

    /**
     * ZIP Code of the Pharmacy
     */
    @NotEmpty
    @Length ( min = 5, max = 10 )
    private String zip;

    /**
     * State of the Pharmacy
     */
    @Enumerated ( EnumType.STRING )
    private State  state;

    /**
     * Returns the name of the Pharmacy
     *
     * @return the name of the pharmacy
     */
    public String getName () {
        return name;
    }

    /**
     * Sets the name of the Pharmacy
     *
     * @param name
     *            the new name
     */
    public void setName ( String name ) {
        this.name = name;
    }

    /**
     * Returns the address of the Pharmacy
     *
     * @return the address of the Pharmacy
     */
    public String getAddress () {
        return address;
    }

    /**
     * Sets the address of the Pharmacy
     *
     * @param address
     *            the new address
     */
    public void setAddress ( String address ) {
        this.address = address;
    }

    /**
     * Returns the address 2 of the Pharmacy
     *
     * @return the address 2 of the Pharmacy
     */
    public String getAddress2 () {
        return address2;
    }

    /**
     * Sets the address 2 of the Pharmacy
     *
     * @param address2
     *            the new address 2
     */
    public void setAddress2 ( String address2 ) {
        this.address2 = address2;
    }

    /**
     * Returns the zip code of the Pharmacy
     *
     * @return the zip code of the Pharmacy
     */
    public String getZip () {
        return zip;
    }

    /**
     * Sets the zip code of the Pharmacy
     *
     * @param zip
     *            the new zip code
     */
    public void setZip ( String zip ) {
        this.zip = zip;
    }

    /**
     * Returns the state of the Pharmacy
     *
     * @return the state of the Pharmacy
     */
    public State getState () {
        return state;
    }

    /**
     * Sets the state of the Pharmacy
     *
     * @param state
     *            the new state
     */
    public void setState ( State state ) {
        this.state = state;
    }

    /**
     * Retrieves the ID (Name) of this Pharmacy
     */
    @Override
    public String getId () {
        return getName();
    }

}
